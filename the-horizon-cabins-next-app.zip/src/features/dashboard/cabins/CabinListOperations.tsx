"use client";

import Filter from "@/components/ui/Filter";
import SortBy from "@/components/ui/SortBy";
import { type ReactNode } from "react";
import CityFilter from "../main/components/FilterBar/CityFilter";

export default function CabinListOperations(): ReactNode {
  function updateParams(updates: Record<string, string | null>) {
    const params = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([key, value]) => {
      if (value === null) params.delete(key);
      else params.set(key, value);
    });
    startTransition(() => {
      router.replace(`${pathname}?${params.toString()}`, { scroll: false });
    });
  }
  return (
    <div className="flex flex-wrap items-center gap-3">
      <Filter
        filterField="discount"
        filterOptions={[
          { value: "all", title: "همه" },
          { value: "with-discount", title: "تخفیف‌دار" },
          { value: "no-discount", title: "بدون تخفیف" },
        ]}
      />

      <Filter
        filterField="capacity"
        filterOptions={[
          { value: "all", title: "همه ظرفیت‌ها" },
          { value: "small", title: "کوچک (تا ۳ نفر)" },
          { value: "medium", title: "متوسط (۴ تا ۷ نفر)" },
          { value: "large", title: "بزرگ (۸ نفر و بیشتر)" },
        ]}
      />
      <CityFilter />

      <div className="mr-auto">
        <SortBy
          options={[
            { value: "name-asc", label: "نام (صعودی)" },
            { value: "name-desc", label: "نام (نزولی)" },
            { value: "regularPrice-asc", label: "مبلغ (ارزان‌ترین)" },
            { value: "regularPrice-desc", label: "مبلغ (گران‌ترین)" },
            { value: "maxCapacity-asc", label: "ظرفیت (کمترین)" },
            { value: "maxCapacity-desc", label: "ظرفیت (بیشترین)" },
          ]}
        />
      </div>
    </div>
  );
}
